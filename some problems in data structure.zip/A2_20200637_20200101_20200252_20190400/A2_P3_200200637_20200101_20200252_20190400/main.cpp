/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>
#include<queue>
using namespace std;

class Yahia_Stack{

private:
    queue<int> MyQueue,MyQueue2;
public:
    Yahia_Stack()
    {

    }
    Yahia_Stack(queue<int> q)
    {
           MyQueue=q;
    }
    int __top()
    {
        if(MyQueue.empty()){return -1;}
        int res=MyQueue.front();
        return res;
    }
    void __pop()
    {
        if(MyQueue.empty())
            return;
        else
            MyQueue.pop();
    }
    void __push(int value)
    {
        MyQueue2.push(value);
        while(!MyQueue.empty())
        {
            MyQueue2.push(MyQueue.front());
            MyQueue.pop();
        }
        queue <int>tmp =MyQueue ;
        MyQueue=MyQueue2;
        MyQueue2=tmp;
    }
    bool isEmpty()
    {
        if(MyQueue.empty())
            return true;
        else
            return false;
    }
    void displayStack()
    {
        queue<int>tmpQ=MyQueue;
        while(!tmpQ.empty()){
            cout<<tmpQ.front()<<" ";
            tmpQ.pop();
        }
        cout<<"\n"<<endl;
    }
};
int main()
{
Yahia_Stack obj;
obj.__push(100);
obj.__push(200);
obj.__push(300);
obj.__push(400);
obj.__push(500);
    cout<<"top :"<<obj.__top()<<endl;
    ///displaying stack
    cout<<"displaying stack : ";
     obj.displayStack();
     ///pop top element
     cout<<"pop top element : ";
     obj.__pop();
     obj.displayStack();
     ///push new element 600 to the top
     cout<<"push new element 600 to the top : ";
     obj.__push(600);
     obj.displayStack();
return 0;

}
