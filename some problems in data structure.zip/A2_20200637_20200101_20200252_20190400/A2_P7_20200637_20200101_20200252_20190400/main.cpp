/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>

using namespace std;

class Node
{
private:
    int item;
    Node *left=0;
    Node* right=0;

public:
    static Node *root;

    Node(int value)  {item = value;}

    void setitem (int value) {item = value;}
    int getitem() {return item;}

    void setright (Node * ptr) {right = ptr;}
    Node* getright (){return right;}

    void setleft (Node *ptr) {left = ptr;}
    Node* getleft(){return left;}

    static void setroot(Node*ptr)// responsible to point to root node so/ this help in passing default parameter to flip function
    {
        root=ptr;
    }

    void VLR (Node* root) //preorderd traverse
    {
        if(root != 0)
        {
            cout<<root->getitem()<<' ';
            VLR(root->getleft());
            VLR (root->getright());
        }
    }

    void flip(Node* node=root)
    {
        {
            if(node!=0)
            {
                if(node->getleft()!=0 && node-> getright()!=0)// swap only when the node points to 2 nodes
                {

                Node temp=(*node->getleft());//temp = to left child of the parent
                *node->getleft()=(*node->getright());// left child = right child
                *node->getright()=temp;// right child = temp
                }


                //recurstion process
               flip(node->getleft());
               flip(node->getright());

            }

            else    {return ;}// base case

        }
    }

};
Node* Node::root=0;



int main()
{
//case 1
    Node*root = new Node(1);
    root->setroot(root);
    root->setleft(new Node(2));
    root->setright(new Node(3)) ;
    root->getleft()->setleft(new Node(4)) ;
    root->getleft()->setright(new Node(5)) ;

    root->VLR(root);
    root->flip();
    cout<<'\t';
    root->VLR (root);
    cout<<endl;
// delete must trace mirror tree not the original one as the objects are swapped

    delete root->getright()->getright();
    delete root->getright()->getleft();
    delete root->getright();
    delete root->getleft();
    delete root;


//case 2
    root = new Node(1);
    root->setroot(root);
    root->setleft(new Node(2));
    root->setright(new Node(3)) ;
    root->getleft()->setleft(new Node(4)) ;
    root->getleft()->setright(new Node(5)) ;
    root->getright()->setleft(new Node(6));
    root->getright()->setright(new Node(7));
    root->getright()->getright()->setleft(new Node (8));

    root->VLR(root);
    root->flip();
    cout<<'\t';
    root->VLR (root);
    cout<<endl;

    delete root->getleft()->getleft()->getleft();//note that node with item=8 not swapped as it doesn't has siblings
    delete root->getleft()->getleft();
    delete root->getleft()->getright();
    delete root->getleft();
    delete root->getright()->getleft();
    delete root->getright()->getright();
    delete root->getright();
    delete root;

//case 3
    root = new Node(1);
    root->setroot(root);
    root->setleft(new Node(2));
    root->getleft()->setright(new Node(3)) ;
    root->getleft()->setleft(new Node(4)) ;

    root->VLR(root);
    root->flip();
    cout<<'\t';
    root->VLR (root);
    cout<<endl;
    delete root->getleft()->getright();
    delete root->getleft()->getleft();
    delete root->getleft();//not swapped as it doesn't have siblings
    delete root;

//case 4
      root = new Node(1);
    root->setroot(root);

    root->VLR(root);
    root->flip();
    cout<<'\t';
    root->VLR (root);
    cout<<endl;

    delete root;// no swap take palce as the tree consist only of parent node

//case 5
    root = new Node(1);
    root->setroot(root);
    root->setleft(new Node(2));
    root->setright(new Node(3));

    root->VLR(root);
    root->flip();
    cout<<'\t';
    root->VLR (root);
    cout<<endl;

    delete root->getleft();
    delete root->getright();
    delete root;






    return 0;
}
