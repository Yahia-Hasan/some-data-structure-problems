/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>
#include<vector>
using namespace std;
class Tickets_Queue{
private:
    vector<int> Line;
    int position;
    int time=0;
    int counter=0;
public:
    Tickets_Queue()
    {
        position=-1;
        Line={0,0,0,0,0,0,0};
    }
    Tickets_Queue(vector<int>l,int k)
    {
        position=k;
        counter=k;
        for(int i=0 ; i<Line.size();i++)
        {
            Line[i]=l[i];
        }
    }



vector<int> re_order(vector<int> line)
    {
        int tmp ;
        tmp=line[0];
         cout<<"iterator number :"<<time<<endl;
        for(int i=0;i<line.size()-1;i++)
        {
            line[i]=line[i+1];
            if(i==line.size()-1)break;

        }
        line[line.size()-1]=tmp;
        for(int i=0;i<line.size();i++)
        {
            cout<<line[i]<<endl;
        }
        cout<<"///////////"<<endl;

        return line ;
    }
void GetIntoQueue(vector<int>line)
    {

        while(line[counter]!=0)
        {
        if(line[0]>0)
        {
            time++;
        }

        line[0]--;
        line=re_order(line);

        if(counter==0)
        {
            counter=line.size();
        }
        counter--;

        }
        cout<<"time = "<<time <<endl;
    }
};

int main()
{
    int sz ;cout<<"enter number of persons :";cin>>sz;
    int val;
    vector<int>l;
    cout<<"Enter number of tickets that each person wants ..."<<endl;
    for(int i=0;i<sz;i++)
    {
        cout<<"person"<<i+1<<":";
        cin>>val;
        l.push_back(val);
        val=0;
    }
    int k;cout<<"enter the index of the person who wants to calculate his time :";cin>>k;
    Tickets_Queue obj(l,k);
    obj.GetIntoQueue(l);
return 0;


}

