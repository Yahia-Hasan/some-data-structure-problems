/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>

using namespace std;
struct TreeNode {
int val;
TreeNode *left;
TreeNode *right;
TreeNode() : val(0), left(nullptr), right(nullptr) {}
TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left),
right(right) {}
};
class Solution {
public:
bool isSameTree(TreeNode* p, TreeNode* q) {
    if (p == NULL && q == NULL)
        return true;
    if (p != NULL && q != NULL)
    {
        return
        (
            p->val == q->val &&
            isSameTree(p->left, q->left) &&
            isSameTree(q->right, p->right)
        );
    }
    return false;
}
};



TreeNode* insertLevelOrder(int arr[], TreeNode* root,
                       int i, int n)
{
    // Base case for recursion
    if (i < n)
    {
        TreeNode* temp = new TreeNode(arr[i]);
        root = temp;

        // insert left child
        root->left = insertLevelOrder(arr,
                   root->left, 2 * i + 1, n);

        // insert right child
        root->right = insertLevelOrder(arr,
                  root->right, 2 * i + 2, n);
    }
    return root;
}


int main()
{
    int arr[] = {1,2,1};
    int arr2[]={1,2,1};
    int n = sizeof(arr)/sizeof(arr[0]);
    TreeNode* root = insertLevelOrder(arr, root, 0, n);
    TreeNode* root2 = insertLevelOrder(arr2, root, 0, n);
    Solution p;
      if(p.isSameTree(root,root2)==true)
       cout<<"Tree is symmtic "<<endl;
  else
        cout<<"Tree is non-symmtic "<<endl;
    return 0;
}
