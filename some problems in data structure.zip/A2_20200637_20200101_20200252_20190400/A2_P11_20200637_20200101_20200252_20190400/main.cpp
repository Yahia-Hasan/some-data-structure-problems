/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>

using namespace std;
template<class T>
class BSTNode
{
public:
    BSTNode<T> *left;
    BSTNode<T> *right;
    T value;

    BSTNode<T>(T val)
    {
        this->value = val;
        left = right = nullptr;
    }
};

template <class T>
class BSTFCI
{

public:
	BSTFCI();
	~BSTFCI();
	void add(T val);
	void printInOrder();
	int size();
	bool ret;
    int dfs();
    bool isBalance();
    BSTNode<T>* insert_at_sub();
    BSTNode<T> * root;
    void  printRange(int n1, int n2);
private:
    BSTNode<T>* insert_at_sub(T i, BSTNode<T>*);
	int treeSize;
	int dfs(BSTNode<T>* node);
	void printInOrder(BSTNode<T> * node);
	void deleteTree(BSTNode<T> * node);
	bool isBalance(BSTNode<T>* root);
};

template <class T>
BSTFCI<T>::BSTFCI(){
	this->root = NULL;
	this->treeSize = 0;
}

template <class T>
BSTFCI<T>::~BSTFCI(){
	deleteTree(this->root);
}

template <class T>
int BSTFCI<T>::size(){
	return this->treeSize;
}
template <class T>
int BSTFCI<T>::dfs(BSTNode<T>* node){
      if(!node)
         return 0;
      int l = 1 + dfs(node->left);
      int r = 1 + dfs(node->right);
      if(abs(l - r) > 1)
         ret = false;
      return max(l, r);
}
template <class T>
bool BSTFCI<T>::isBalance() {
      ret = true;
      dfs(root);
      return ret;
}


template <class T>
void BSTFCI<T>::add(T node)
    {
        ++treeSize;

        root = insert_at_sub(node, root);
    }
template <class T>
BSTNode<T>* BSTFCI<T>::insert_at_sub(T i, BSTNode<T> *p)
{
    if( ! p )
        return new BSTNode<T>(i);
    else if (i <= p->value)
        p->left = insert_at_sub(i, p->left);
    else if (i > p->value)
        p->right = insert_at_sub(i, p->right);

    return p;
}

template <class T>
void BSTFCI<T>::printInOrder(){
	printInOrder(this->root);
	std::cout << std::endl;
}

template <class T>
void BSTFCI<T>::printInOrder(BSTNode<T>* node){
	if(node != NULL){
		printInOrder(node->left);
		std::cout << node->value << "  ";
		printInOrder(node->right);
	}
}



template <class T>
void BSTFCI<T>::deleteTree(BSTNode<T>* node){
	if(node != NULL){
		deleteTree(node->left);
		deleteTree(node->right);
		delete node;
	}
}



void test1IsBalance()
{
    BSTFCI<int> tree;
    tree.add(5);
	tree.add(4);
	tree.add(7);
	tree.add(10);
	tree.add(1);
	tree.add(2);
	tree.printInOrder();

cout << "isBalance "<< ((tree.isBalance())? "true" : "false" ) <<endl;

}
void test2IsBalance()
{
    BSTFCI<int> tree;
    tree.add(5);
	tree.add(4);
	tree.add(7);
	tree.printInOrder();
cout << "isBalance "<< ((tree.isBalance())? "true" : "false" ) <<endl;

}
void test3IsBalance()
{
    BSTFCI<int> tree;
    tree.add(5);
	tree.add(3);
	tree.add(7);
    tree.add(1);
	tree.add(4);
	tree.printInOrder();

cout << "isBalance "<< ((tree.isBalance())? "true" : "false" ) <<endl;

}
void test4IsBalance()
{
    BSTFCI<int> tree;
    tree.add(5);
	tree.add(4);
	tree.add(7);
	tree.add(10);
	tree.add(11);
	tree.add(12);
	tree.printInOrder();

cout << "isBalance "<< ((tree.isBalance())? "true" : "false" ) <<endl;

}
void test5IsBalance()
{
    BSTFCI<int> tree;
    tree.add(10);
	tree.add(20);
	tree.add(5);
	tree.add(7);
	tree.add(3);
	tree.add(15);
	tree.add(30);
	tree.printInOrder();

cout << "isBalance "<< ((tree.isBalance())? "true" : "false" ) <<endl;
}
template <class T>
bool areIdentical(BSTNode<T> * root1, BSTNode<T> *root2)
{
    if (root1 == NULL && root2 == NULL)
        return true;
   else if (root1!=NULL && root2!=NULL)
   {
      return((root1->value == root2->value)&&(areIdentical(root1->left, root2->left))
             &&(areIdentical(root1->right, root2->right)));
   }
    else if((root1 != NULL && root2 == NULL)) return(false);
}
template <class T>
bool isSubTree(BSTFCI<T> t1, BSTFCI<T> t2)
{
   return isSub(t1.root,t2.root);
}
template <class T>
bool isSub(BSTNode<T>* n1, BSTNode<T>* n2)
{
    if (n2 == NULL)
        return true;
    if (n1 == NULL)
        return false;
    if (areIdentical(n1, n2))
        return true;
    return (isSub(n1->left, n2)||isSub(n1->right, n2));
}

void test1IsSubTree()
{
    BSTFCI<int> tree1;
    tree1.add(5);
	tree1.add(3);
	tree1.add(2);
	tree1.add(1);
	tree1.add(4);
	tree1.add(7);
	tree1.add(9);
    tree1.add(8);
	tree1.add(10);

    BSTFCI<int> tree2;
	tree2.add(9);
    tree2.add(8);
	tree2.add(10);

   cout<<"\nTree1 ";  tree1.printInOrder();
   cout<<"Tree2 ";  tree2.printInOrder();
   cout << "IsSubTree? "<< ((isSubTree(tree1,tree2))? "True" : "False" ) <<endl;


}
void test2IsSubTree()
{
    BSTFCI<char> tree1;
    tree1.add('p');
	tree1.add('o');
	tree1.add('l');
	tree1.add('r');
	tree1.add('u');
	tree1.add('d');
	tree1.add('c');
    BSTFCI<char> tree2;
    tree2.add('s');
	tree2.add('z');
    tree2.add('a');
   cout<<"\nTree1:- ";  tree1.printInOrder();
   cout<<"Tree2:- ";  tree2.printInOrder();
   cout << "IsSubTree? "<< ((isSubTree(tree1,tree2))? "True" : "False" ) <<endl;


}
void test3IsSubTree()
{
    BSTFCI<int> tree1;
    tree1.add(1);
	tree1.add(2);
	tree1.add(5);
	tree1.add(7);
	tree1.add(3);
	tree1.add(6);
	tree1.add(4);
    BSTFCI<int> tree2;
    tree2.add(4);
	tree2.add(3);
    tree2.add(2);
   cout<<"\nTree1:- ";  tree1.printInOrder();
   cout<<"Tree2:- ";  tree2.printInOrder();
   cout << "IsSubTree? "<< ((isSubTree(tree1,tree2))? "True" : "False" ) <<endl;


}
void test4IsSubTree()
{
    BSTFCI<char> tree1;
    tree1.add('p');
	tree1.add('o');
	tree1.add('l');
	tree1.add('r');
	tree1.add('u');
	tree1.add('d');
	tree1.add('c');
    BSTFCI<char> tree2;
	tree2.add('r');
    tree2.add('u');
   cout<<"\nTree1:- ";  tree1.printInOrder();
   cout<<"Tree2:- ";  tree2.printInOrder();
   cout << "IsSubTree? "<< ((isSubTree(tree1,tree2))? "True" : "False" ) <<endl;


}
void test5IsSubTree()
{
    BSTFCI<int> tree1;
    tree1.add(1000);
	tree1.add(2000);
	tree1.add(5000);
	tree1.add(7000);
	tree1.add(300);
	tree1.add(1500);
	tree1.add(3000);
    BSTFCI<int> tree2;
    tree2.add(5000);
    tree2.add(3000);
    tree2.add(7000);


   cout<<"\nTree1:- ";  tree1.printInOrder();
   cout<<"Tree2:- ";  tree2.printInOrder();
   cout << "IsSubTree? "<< ((isSubTree(tree1,tree2))? "True" : "False" ) <<endl;


}
template <class T>
void BSTFCI<T>::printRange(int n1, int n2)
{
    if (!root)
        return;

    BSTNode<T>* curr = root;
cout<<"[ ";
    while (curr) {

        if (curr->left == NULL)
        {
            if (curr->value <= n2 &&
                curr->value >= n1)
            {
                cout << curr->value << "   ";
            }

            curr = curr->right;
        }

        else {
            BSTNode<T>* pre = curr->left;
            while (pre->right != NULL &&
                   pre->right != curr)
                        pre = pre->right;

            if (pre->right == NULL)
            {
                pre->right = curr;
                curr = curr->left;
            }

            else {
                pre->right = NULL;
                if (curr->value <= n2 &&
                    curr->value >= n1)
                {
                    cout << curr->value << "   ";
                }

                curr = curr->right;
            }
        }
    }
    cout<<"]";
}

void test1printRange()
{
    BSTFCI<int> tree;
    tree.add(10);
	tree.add(20);
	tree.add(5);
	tree.add(7);
	tree.add(3);
	tree.add(15);
	tree.add(30);
	cout<<"Tree :- ";tree.printInOrder();
	cout<<"Range (6,20)";
	tree.printRange(6,20);
    cout<<endl;

}
void test2printRange()
{
    BSTFCI<int> tree;
    tree.add(100);
	tree.add(200);
	tree.add(50);
	tree.add(70);
	tree.add(300);
	tree.add(120);
	tree.add(20);
	cout<<"Tree :- ";tree.printInOrder();
	cout<<"Range (100,200)";
	tree.printRange(100,200);
    cout<<endl;

}
void test3printRange()
{
    BSTFCI<int> tree;
    tree.add(10);
	tree.add(20);
	tree.add(5);
	tree.add(7);
	tree.add(3);
	cout<<"Tree :- ";tree.printInOrder();
	cout<<"Range (6,6)";
	tree.printRange(6,6);
    cout<<endl;

}
void test4printRange()
{
    BSTFCI<int> tree;
    tree.add(1010);
	tree.add(2020);
	tree.add(5050);
	tree.add(7010);
	tree.add(3012);
	tree.add(1811);
	tree.add(3011);
	cout<<"Tree :- ";tree.printInOrder();
	cout<<"Range (2020,5050)";
	tree.printRange(2020,5050);
    cout<<endl;

}
void test5printRange()
{
    BSTFCI<int> tree;
    tree.add(1);
	tree.add(2);
	tree.add(5);
	tree.add(7);
	tree.add(3);
	tree.add(10);
	tree.add(3);
	cout<<"Tree :- ";tree.printInOrder();
	cout<<"Range (3,20)";
	tree.printRange(3,20);
    cout<<endl;
}
int main()
{
test1IsBalance();
test2IsBalance();
test3IsBalance();
test4IsBalance();
test5IsBalance();
test1printRange();cout<<endl;
test2printRange();cout<<endl;
test3printRange();cout<<endl;
test4printRange();cout<<endl;
test5printRange();cout<<endl;
test1IsSubTree();cout<<endl;
test3IsSubTree();cout<<endl;
test5IsSubTree();cout<<endl;
test2IsSubTree();cout<<endl;
test4IsSubTree();cout<<endl;
    return 0;
}
