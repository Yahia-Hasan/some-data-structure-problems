/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>
#include<string>

using namespace std;


void printPostOrder (string preorder, string inorder)
{
    int length=preorder.length();//can be also taken from inorder string

    if(length==1)
    {
        cout<< preorder.front();
        return;
        }

    else
    {
        //last index +1 = length-> this note relate to  [ substr() parameters]


        int index=inorder.find(preorder.front()); //FIND position of first element in (preorder string) in the inorder string




        if(index!=0)// in case of preorder[0]==inorder[0]=true ->all  remaining nodes will be right child
                    //case 3 give error wihout this condational statement
        {
        printPostOrder(preorder.substr(1,index),inorder.substr(0,index));
        // left characters passed as preorder or inorder must be the same ignoring there order in string
        }


        if(index!=length-1)//case of inorder[index] is the last character in inorder string -> there will be no right child nodes
        {                  //case 3 give error wihout this condational statement

        printPostOrder(preorder.substr(index+1,(length-1)-index),inorder.substr(index+1,(length-1)-index));
        // right characters passed as preorder or inorder must be the same ignoring there order in string
        }
        cout<< preorder.front();// first elemet in preorder is last element in postorder


    }
}

int main()
{
//case 1
cout<<"preorder: "<<"ABFGC"<<endl;
cout<<"inorder: "<<"FBGAC"<<endl;
cout<<"postorder: ";
printPostOrder("ABFGC","FBGAC");
cout<<endl<<endl;


//case 2
cout<<"preorder: "<<"ABDEHICFG"<<endl;
cout<<"inorder: "<<"DBHEIAFCG"<<endl;
cout<<"postorder: ";
printPostOrder("ABDEHICFG","DBHEIAFCG");
cout<<endl<<endl;

//case 3
cout<<"preorder: "<<"ABDEHICFG"<<endl;
cout<<"inorder: "<<"DBHEIFCAG"<<endl;
cout<<"postorder: ";
printPostOrder("ABDEHICFG","DBHEIFCAG");
cout<<endl<<endl;

//case 4

cout<<"preorder: "<<"ABCD"<<endl;
cout<<"inorder: "<<"ADBC"<<endl;
cout<<"postorder: ";
printPostOrder("ABCD","ADBC");
cout<<endl<<endl;

//case 5
// this case is like a linked list whrere each node has only one child
cout<<"preorder: "<<"ABCD"<<endl;
cout<<"inorder: "<<"DCBA"<<endl;
cout<<"postorder: ";
printPostOrder("ABCD","DCBA");
cout<<endl<<endl;


    return 0;
}
