/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>

using namespace std;
struct Node
{
    int data;
    Node* left, * right;
};

Node* newNode(int data)
{
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->left = node->right = NULL;
    return (node);
}
Node* insertLevelOrder(int arr[], Node* root,
                       int i, int n)
{
    if (i < n)
    {
        Node* temp = newNode(arr[i]);
        root = temp;
        root->left = insertLevelOrder(arr,
                   root->left, 2 * i + 1, n);
        root->right = insertLevelOrder(arr,
                  root->right, 2 * i + 2, n);
    }
    return root;
}
int Calculating_the_sum(Node *root, int k, int &count)
{
    if (root == NULL)
        return 0;
    if (count > k)
        return 0;

    int res = Calculating_the_sum(root->left, k, count);
    if (count >= k)
        return res;

    res += root->data;

    count++;
    if (count >= k)
      return res;
    return res + Calculating_the_sum(root->right, k, count);
}
int ksmallestElementSum(struct Node *root, int k)
{
   int count = 0;
   Calculating_the_sum(root, k, count);
}
int test1()
{
    int arr[] = { 54,51,75,49,52,74,85 };
    int n = sizeof(arr)/sizeof(arr[0]);
    Node* root = insertLevelOrder(arr, root, 0, n);
    int k=3;
    return  ksmallestElementSum(root, k);
///       54
///      /   \
///    51     75
///   / \     / \             ///152
///  49  52  74  85
}
int test2()
{
    int arr[] = {5,3,9,2,4,7,10};
    int n = sizeof(arr)/sizeof(arr[0]);
    Node* root = insertLevelOrder(arr, root, 0, n);
    int k=4;
    return  ksmallestElementSum(root, k);
///        5
///      /   \
///    3       9
///   / \     / \             ///14
///  2   4   7   10
}
int test3()
{
    int arr[] = {100,30,120,10,NULL,110,200};
    int n = sizeof(arr)/sizeof(arr[0]);
    Node* root = insertLevelOrder(arr, root, 0, n);
    int k=2;
    return  ksmallestElementSum(root, k);
///       100
///      /   \
///    30     120
///   / \     / \             ///40
///  10 null 110  200
}
int test4()
{
    int arr[] = {7,3,12,1,5,4,20};
    int n = sizeof(arr)/sizeof(arr[0]);
    Node* root = insertLevelOrder(arr, root, 0, n);
    int k=5;
    return  ksmallestElementSum(root, k);
///        7
///      /   \
///    3      12
///   / \     / \             ///20
///  1   5   4   20
}
int test5()
{
    int arr[] = {20,10,30,5,15,25,35,0,1,11};
    int n = sizeof(arr)/sizeof(arr[0]);
    Node* root = insertLevelOrder(arr, root, 0, n);
    int k=7;
    return  ksmallestElementSum(root, k);
///          20
///        /    \
///      10      30
///     / \      / \             ///62
///    5   15   25  35
///   / \  /
///  0  1 11
}
int main()
{
    cout<<test1()<<endl;
    cout<<test2()<<endl;
    cout<<test3()<<endl;
    cout<<test4()<<endl;
    cout<<test5()<<endl;
    return 0;
}
