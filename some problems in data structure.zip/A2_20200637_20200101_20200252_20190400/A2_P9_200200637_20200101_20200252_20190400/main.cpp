/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include<iostream>
using namespace std;

class BTnode
{
public:
    int item=0;
    BTnode * left=nullptr;
    BTnode * right=nullptr;


    bool fold(BTnode *LEFT,BTnode *RIGHT)
    {
        bool result;
        if(LEFT==RIGHT)//this case happen only on first call in main()
        {
            if(LEFT->left!=nullptr&&RIGHT->right!=nullptr)  {return fold(LEFT->left,RIGHT->right);}
            else if(LEFT->left==nullptr&&RIGHT->right==nullptr){return true;}
            else    {return false;}
        }



         else if(LEFT!=RIGHT)
        {
            // note that two nested conditional statements are independent
            bool result1;
            bool result2;

            if(LEFT->left!=nullptr&&RIGHT->right!=nullptr)  { result1= fold(LEFT->left,RIGHT->right);}
            else if (LEFT->left==nullptr&&RIGHT->right==nullptr)    {result1= true;}
            else {result1=false;}


            if(LEFT->right!=nullptr&&RIGHT->left!=nullptr) {result2=fold(LEFT->right,RIGHT->left);}
            else if(LEFT->right==nullptr&&RIGHT->left==nullptr) {result2=true;}
            else    {result2=false;}

            return result1&&result2;
        }

    }
};





int main()
{

    bool result;
    //case 1: foldable
    /* the next code construct the following tree
            @
          /   \
         @     @
        / \   / \
       @   @ @   @


    */
  BTnode*root=new BTnode;
  root->left=new BTnode;
  root->right=new BTnode;
  root->left->left=new BTnode;
  root->right->right=new BTnode;
  root->right->left=new BTnode;
  root->left->right=new BTnode;
  result=root->fold(root,root);
  if(result){cout<<"tree 1 is foldable\n";}
  else {cout<<"tree 1 isn't foldable\n";}

  delete root->right->right;
  delete root->left->right;
  delete root->right->left;
  delete root->left->left;
  delete root->right;
  delete root->left;
  delete root;

  //case 2: foldable
    /* the next code construct the following tree
            @
          /   \
         @     @
        / \   / \
       @   @ @   @
      /           \
     @             @
    */
  root=new BTnode;
  root->left=new BTnode;
  root->right=new BTnode;
  root->left->left=new BTnode;
  root->right->left=new BTnode;
  root->left->right=new BTnode;
  root->right->right=new BTnode;
  root->right->right->right=new BTnode;
  root->left->left->left=new BTnode;
  root->left->left->right=new BTnode;
  root->right->right->left=new BTnode;
  result=root->fold(root,root);
  if(result){cout<<"tree 2 is foldable\n";}
  else {cout<<"tree 2 isn't foldable\n";}

  delete  root->right->right->left;
  delete root->left->left->right;
  delete root->left->left->left;
  delete root->right->right ->right;
  delete root->right->right;
  delete root->left->right;
  delete root->right->left;
  delete root->left->left;
  delete root->right;
  delete root->left;
  delete root;

  //case 3 : not foldable
   /* the next code construct the following tree
             @
          /     \
         @       @
        / \     /  \
       @   @   @    @
      /     \        \
     @       @        @
    */
  root=new BTnode;
  root->left=new BTnode;
  root->right=new BTnode;
  root->left->left=new BTnode;
  root->right->left=new BTnode;
  root->left->right=new BTnode;
  root->right->right=new BTnode;
  root->right->right->right=new BTnode;
  root->left->left->left=new BTnode;
  root->left->left->right=new BTnode;
  root->right->right->left=new BTnode;
  root->left->right->right=new BTnode;
  result=root->fold(root,root);
  if(result){cout<<"tree 3 is foldable\n";}
  else {cout<<"tree 3 isn't foldable\n";}

  delete root->left->right->right;
  delete  root->right->right->left;
  delete root->left->left->right;
  delete root->left->left->left;
  delete root->right->right ->right;
  delete root->right->right;
  delete root->left->right;
  delete root->right->left;
  delete root->left->left;
  delete root->right;
  delete root->left;
  delete root;

  //case 4: foldable
   /* the next code construct the following tree
              @
           /      \
         @         @
        / \       /  \
       @   @     @    @
      /     \   /      \
     @       @ @        @
    */
  root=new BTnode;
  root->left=new BTnode;
  root->right=new BTnode;
  root->left->left=new BTnode;
  root->right->left=new BTnode;
  root->left->right=new BTnode;
  root->right->right=new BTnode;
  root->right->right->right=new BTnode;
  root->left->left->left=new BTnode;
  root->left->left->right=new BTnode;
  root->right->right->left=new BTnode;
  root->left->right->right=new BTnode;
  root->right->left->left=new BTnode;
  result=root->fold(root,root);
  if(result){cout<<"tree 4 is foldable\n";}
  else {cout<<"tree 4 isn't foldable\n";}


  delete root->right->left->left;
  delete root->left->right->right;
  delete  root->right->right->left;
  delete root->left->left->right;
  delete root->left->left->left;
  delete root->right->right ->right;
  delete root->right->right;
  delete root->left->right;
  delete root->right->left;
  delete root->left->left;
  delete root->right;
  delete root->left;
  delete root;

  //case 5: not foldable
   /* the next code construct the following tree
              @
           /      \
         @         @
        / \       /  \
       @   @     @    @
      /     \   /      \
     @       @ @        @
                       / \
                      @   @
    */
  root=new BTnode;
  root->left=new BTnode;
  root->right=new BTnode;
  root->left->left=new BTnode;
  root->right->left=new BTnode;
  root->left->right=new BTnode;
  root->right->right=new BTnode;
  root->right->right->right=new BTnode;
  root->left->left->left=new BTnode;
  root->left->left->right=new BTnode;
  root->right->right->left=new BTnode;
  root->left->right->right=new BTnode;
  root->right->left->left=new BTnode;
  root->right->right->right->right=new BTnode;
  root->right->right->right->left=new BTnode;
  result=root->fold(root,root);
  if(result){cout<<"tree 4 is foldable\n";}
  else {cout<<"tree 4 isn't foldable\n";}


  delete root->right->right->right->left;
  delete root->right->right->right->right;
  delete root->right->left->left;
  delete root->left->right->right;
  delete root->right->right->left;
  delete root->left->left->right;
  delete root->left->left->left;
  delete root->right->right ->right;
  delete root->right->right;
  delete root->left->right;
  delete root->right->left;
  delete root->left->left;
  delete root->right;
  delete root->left;
  delete root;







    return 0;
}

