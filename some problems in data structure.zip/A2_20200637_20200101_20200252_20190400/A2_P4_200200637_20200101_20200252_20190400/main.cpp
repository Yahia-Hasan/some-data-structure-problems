/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>
using namespace std;
struct TreeNode {
int val;
TreeNode *left;
TreeNode *right;
TreeNode() : val(0), left(nullptr), right(nullptr) {}
TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left),
right(right) {}
};
class Solution {
private:
    TreeNode *temp;
public:
bool isSymmetric(TreeNode* root) {
 return isMirror(root,root);

}
bool isMirror(struct TreeNode *root1,struct TreeNode *root2)
    {
        if(root1==NULL&&root2==NULL)
        {
            return true;
        }
        if(root1&&root2&&root1->val==root2->val)
        {
            return isMirror(root1->left,root2->right)&&isMirror(root1->right,root2->left);
        }
        return false ;
    }
};
TreeNode* insertLevelOrder(int arr[], TreeNode* root,
                       int i, int n)
{
    if (i < n)
    {
        TreeNode* temp = new TreeNode(arr[i]);
        root = temp;
        root->left = insertLevelOrder(arr,
                   root->left, 2 * i + 1, n);
        root->right = insertLevelOrder(arr,
                  root->right, 2 * i + 2, n);
    }
    return root;
}


int main()
{
///test1
    int arr[] = {1,2,2,NULL,3,NULL,3};
    int n = sizeof(arr)/sizeof(arr[0]);
    TreeNode* root = insertLevelOrder(arr, root, 0, n);
    Solution r;
    if(r.isSymmetric(root)==true)
       cout<<"Tree is symmtic "<<endl;
       else
        cout<<"Tree is non-symmtic "<<endl;

 ///test2
  int arr2[] = {1,2,2,3,4,4,3};
  int n2 = sizeof(arr2)/sizeof(arr2[0]);
  TreeNode* root2 = insertLevelOrder(arr2, root2, 0, n2);
  Solution r2;
  if(r2.isSymmetric(root2)==true)
       cout<<"Tree is symmtic "<<endl;
  else
        cout<<"Tree is non-symmtic "<<endl;
    return 0;
}


