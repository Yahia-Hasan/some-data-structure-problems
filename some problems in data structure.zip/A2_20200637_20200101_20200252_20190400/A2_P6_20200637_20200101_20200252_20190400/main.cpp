/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <bits/stdc++.h>
#include <iostream>
#include<string>
using namespace std;
struct TreeNode{
string expression ;
TreeNode *left=NULL ,*right=NULL ;
TreeNode(string ex)
{
    expression=ex;
}
};
int TurnIntoIntegr(string expression)
{
    int result=0;
        for(int i=0;i<expression.length();i++)
        {
            result=result*10+(int(expression[i])-48);
        }

    return result;
}
int TreeEvaluation(TreeNode *root)
{
    ///empty tree
    if(!root){return 0;}
    ///turn leaf nodes into integer
    if(!root->left&&!root->right){return TurnIntoIntegr(root->expression);}
    ///evaluate left and right subtree
    int left_value=TreeEvaluation(root->left);
    int right_value=TreeEvaluation(root->right);
    ///check operator to apply
    if(root->expression=="+"){return left_value+right_value;}
    else if (root->expression=="-"){return left_value-right_value;}
    else if (root->expression=="*"){return left_value*right_value;}
    else if (root->expression=="/"){return left_value/right_value;}
}
void test1()
{
    TreeNode *root = new TreeNode("+");
    root->left = new TreeNode("*");
    root->left->left = new TreeNode("5");
    root->left->right = new TreeNode("4");
    root->right = new TreeNode("-");
    root->right->left = new TreeNode("100");
    root->right->right = new TreeNode("20");
    cout << TreeEvaluation(root) << endl;

}
void test2()
{
    TreeNode *root = new TreeNode("+");
    root->left = new TreeNode("3");
    root->right = new TreeNode("*");
    root->right->left = new TreeNode("4");
    root->right->right = new TreeNode("/");
    root->right->right->right = new TreeNode("2");
    root->right->right->left = new TreeNode("8");
    cout << TreeEvaluation(root) << endl;
}
void test3()
{
    TreeNode *root = new TreeNode("-");
    root->left = new TreeNode("10");
    root->right = new TreeNode("20");
    cout << TreeEvaluation(root) << endl;
}
void test4()
{
    TreeNode *root = new TreeNode("+");
    root->left = new TreeNode("*");
    root->right = new TreeNode("/");
    root->right->left = new TreeNode("21");
    root->right->right = new TreeNode("7");
    root->left->left = new TreeNode("-");
    root->left->right = new TreeNode("5");
    root->left->left->left = new TreeNode("10");
    root->left->left->right = new TreeNode("5");
    cout << TreeEvaluation(root) << endl;
}
void test5()
{
    TreeNode *root = new TreeNode("+");
    root->left = new TreeNode("*");
    root->right = new TreeNode("-");
    root->right->left = new TreeNode("17");
    root->right->right = new TreeNode("5");
    root->left->right = new TreeNode("/");
    root->left->left = new TreeNode("3");
    root->left->right->left = new TreeNode("+");
    root->left->right->right = new TreeNode("4");
    root->left->right->left->left = new TreeNode("7");
    root->left->right->left->right = new TreeNode("1");
    cout << TreeEvaluation(root) << endl;

}
int main()
{


test1();
test2();
test3();/// 10-20=-10
test4();///(10-5)*5+(21/7)=28
test5();/// 3*(7+1)/4+(17-5)=18

    return 0;
}
