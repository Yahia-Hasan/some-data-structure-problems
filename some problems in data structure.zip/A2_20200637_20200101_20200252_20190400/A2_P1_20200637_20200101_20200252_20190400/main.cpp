/*
name 1 : yahia hasan ewas 20200637
name 2 : ayat ali hasan 20200101
name 3 : mark raouf wadee 20190400
name 4 : shrouk sayed kasseb 20200252
*/
#include <iostream>

using namespace std;
struct Node {
   char data;
    Node* link;
};
class stack
{
    private :
       Node* top;
    public :
        stack (){top=new Node();}
        ~stack(){delete[]top;}
    void push(char data)
    {
        Node* temp = new Node();
          if (!temp)
        {
           cout << "\nStack Overflow";
           exit(1);
        }
         temp->data = data;
         temp->link = top;
         top = temp;

    }
      void pop()
      {
            if(top==NULL)
            cout<<"Stack Empty"<<endl;
            else {
            top = top->link;
                 }
      }
      void display()
    {
        Node* temp;
       if (top == NULL)
      {
          cout << "\nStack Empty";
          exit(1);
      }
      else
      {
          temp = top;
          while (temp != NULL)
         {
            cout << temp->data ;
            temp = temp->link;
         }
      }
    }
      int isEmpty()

     {
         return top == NULL;
     }

     int Top()
     {
         if (!isEmpty())
        return top->data;
        else
        exit(1);
     }


};
void simplifiedPath(string path)
{
    if(path[0]=='/')
    {
        stack s;
        if(path[path.size()-1]!='/')
        {
            s.push(path[path.size()-1]);
        }
        for(int i=path.size()-2;i>=1;i--)
        {

            if(path[i]=='/'&&path[i-1]=='/')
            {
                s.push(path[i]);
                i--;
            }
            else if(path[i]=='.')
            {
                continue;
            }
            else
            {
                s.push(path[i]);
            }

        }
        s.push('/');
        s.display();

    }
    else
    {
        cout<<"not a path .. path should start with / \n";
    }
}
int main()
{
    string u="/home//foo/";
    cout<<"path = "<<u<<endl;
    cout<<"True path = ";simplifiedPath(u);
    cout<<endl;
    string p="/../";
    cout<<"path = "<<p<<endl;
    cout<<"True path = ";simplifiedPath(p);
    cout<<endl;
    string o="/home/";
    cout<<"path = "<<o<<endl;
    cout<<"True path = ";simplifiedPath(o);
    return 0;
}
